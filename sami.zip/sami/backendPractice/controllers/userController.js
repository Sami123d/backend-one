export const signupController = (req, res) => {
    res.send("signup user")
}

export const loginController = ( req, res) => {
    res.send("login sucessfully")
}