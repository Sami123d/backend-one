import express from "express"
const userRoute = express.Router()

import {signupController, loginController} from "../controllers/userController.js"

userRoute.get("/signup", signupController)
userRoute.get("/login", loginController)

export {userRoute}